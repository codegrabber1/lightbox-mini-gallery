<?php
/**
 * Plugin Name: Lightbox mini gallery.
 * Description: Displays lightbox gallery in posts.
 * Plugin URI:
 * Version: 1.0
 * Author: codegrabber
 * Author Email: [makecodework@gmail.com]
 */
remove_shortcode( 'gallery' );
add_shortcode( 'gallery', 'cg_gallery' );
add_action( 'wp_enqueue_scripts', 'cg_styles_scripts' );

function cg_styles_scripts() {
    wp_register_script( 'cg-lightbox-js', plugins_url( 'js/lightbox.js', __FILE__ ), array( 'jquery' ) );
    wp_register_style( 'cg-lightbox-css', plugins_url( 'css/lightbox.css',__FILE__ ) );
    wp_register_style( 'cg-lightbox-style', plugins_url( 'css/lightbox-style.css',__FILE__ ) );

    wp_enqueue_script( 'cg-lightbox-js' );
    wp_enqueue_style( 'cg-lightbox-css' );
    wp_enqueue_style( 'cg-lightbox-style' );
}

function cg_gallery( $atts ) {
    $img_id = explode( ',', $atts[ 'ids' ] );
    if( !$img_id[0] ) return "<div class='cg_gallery_warning'>_e( 'There are no pictures in the gallery' )</div>";
    $html = "<h4>Для перегляду фото в повному розмірі натисніть на нього.</h4>";
    $html .= "<div class='cg_gallery'>";

    foreach( $img_id as $item ) {
        $img_data = get_posts( array(
            'p' => $item,
            'post_type' => 'attachment'
            ) );
        @$img_desc       = $img_data[0]->post_content;
        @$img_caption    = $img_data[0]->post_excerpt;
        @$img_title      = $img_data[0]->post_title;

        $img_thumb      = wp_get_attachment_image_src( $item, 'large' );
        $img_full       = wp_get_attachment_image_src( $item, 'full' );

        $html .= "<div class='lm-pic'>";
        $html .= "<a href='{$img_full[0]}' data-lightbox='gallery' data-title='{$img_caption}'>
                    <img src='{$img_thumb[0]}' width='{$img_thumb[1]}' height='{$img_thumb[2]}' alt='{$img_title}'>
                  </a>";
        $html .= "</div>";
    }
    $html .= "</div>";
    return $html;
}